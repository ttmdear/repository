package spring5aop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring5AopApplicationTests {

	@Test
	void contextLoads() {
	}

}
